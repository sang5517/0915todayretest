package Exam2.java;

public class Exam2 {
    public static void main(String[] args) {

        // 높이를 입력해주세요 : 3                // 출력

        /*

         *

         ***

         *****


        */
        int high = 3;
        for(int h = 0; h < 3; h++) {
            System.out.println("  *");
            System.out.println(" ***");
            System.out.println("*****");
        }

        // 높이를 입력해주세요 : 5

        // 출력

        /*

              *

             ***

            *****

           *******

          *********

         */
        int high1 = 5;
        for(int h1 = 0; h1 < 5; h1++) {
            System.out.println("    *" );
            System.out.println("   ***" );
            System.out.println("  *****" );
            System.out.println(" *******");
            System.out.println("*********");
        }

        // 높이를 입력해주세요 : 7

        // 출력

        /*

         *

         ***

         *****

         *******

         *********

         ***********

         *************

         */
        int high2 = 7;
        for (int h2 = 0; h2 < 7; h2++) {
            System.out.println("      *");
            System.out.println("     ***");
            System.out.println("    *****");
            System.out.println("   *******");
            System.out.println("  *********");
            System.out.println(" ***********");
            System.out.println("*************");
        }


    }
}
